#include "util.h"

#define SYS_GETDENTS 141
#define SYS_WRITE 4
#define STDOUT 1
#define STDIN 0
#define SYS_READ 3
#define OPEN 5
#define READ 0
#define WRITE 1
#define CLOSE 6
#define CREAT 64
#define READDIR 89

typedef struct ent{
	int inode;
 	int offset;
	short len;
	char buf[1];
}ent;


int main(int argc, char** argv){
	char buf[2000];
	int fd;
	ent *entp=buf;
	int count;
	fd=system_call(5,".",0,0);
	/*if(fd<0)
		exit(85);*/
	count=system_call(141, fd, buf, 100);	
	
	int i;
	for(i=0; i<count; i++){
		system_call(SYS_WRITE, STDOUT,& entp, 1);
		entp++;
	}
	/*entp+=(sizeof(int)*2 + sizeof(short))+1;*/

	return 0;
} 
